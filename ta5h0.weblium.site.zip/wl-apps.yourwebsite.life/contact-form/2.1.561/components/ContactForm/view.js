!(function (e, t) {
  if ("object" == typeof exports && "object" == typeof module)
    module.exports = t();
  else if ("function" == typeof define && define.amd) define([], t);
  else {
    var r = t();
    for (var n in r) ("object" == typeof exports ? exports : e)[n] = r[n];
  }
})(self, () =>
  (() => {
    var e,
      t,
      r,
      n,
      o = {
        1053: (e) => {
          "use strict";
          e.exports = React;
        },
        3107: (e) => {
          "use strict";
          e.exports = ReactDOM;
        },
      },
      a = {};
    function i(e) {
      var t = a[e];
      if (void 0 !== t) return t.exports;
      var r = (a[e] = { exports: {} });
      return o[e].call(r.exports, r, r.exports, i), r.exports;
    }
    return (
      (i.m = o),
      (i.amdO = {}),
      (i.n = (e) => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return i.d(t, { a: t }), t;
      }),
      (i.d = (e, t) => {
        for (var r in t)
          i.o(t, r) &&
            !i.o(e, r) &&
            Object.defineProperty(e, r, { enumerable: !0, get: t[r] });
      }),
      (i.f = {}),
      (i.e = (e) =>
        Promise.all(Object.keys(i.f).reduce((t, r) => (i.f[r](e, t), t), []))),
      (i.u = (e) => (122 === e ? "contact-form-chunk" : e) + ".js"),
      (i.miniCssF = (e) => e + ".view.css"),
      (i.g = (function () {
        if ("object" == typeof globalThis) return globalThis;
        try {
          return this || new Function("return this")();
        } catch (e) {
          if ("object" == typeof window) return window;
        }
      })()),
      (i.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t)),
      (e = {}),
      (t = "contact-form:"),
      (i.l = (r, n, o, a) => {
        if (e[r]) e[r].push(n);
        else {
          var c, s;
          if (void 0 !== o)
            for (
              var u = document.getElementsByTagName("script"), l = 0;
              l < u.length;
              l++
            ) {
              var d = u[l];
              if (
                d.getAttribute("src") == r ||
                d.getAttribute("data-webpack") == t + o
              ) {
                c = d;
                break;
              }
            }
          c ||
            ((s = !0),
            ((c = document.createElement("script")).charset = "utf-8"),
            (c.timeout = 120),
            i.nc && c.setAttribute("nonce", i.nc),
            c.setAttribute("data-webpack", t + o),
            (c.src = r)),
            (e[r] = [n]);
          var f = (t, n) => {
              (c.onerror = c.onload = null), clearTimeout(p);
              var o = e[r];
              if (
                (delete e[r],
                c.parentNode && c.parentNode.removeChild(c),
                o && o.forEach((e) => e(n)),
                t)
              )
                return t(n);
            },
            p = setTimeout(
              f.bind(null, void 0, { type: "timeout", target: c }),
              12e4
            );
          (c.onerror = f.bind(null, c.onerror)),
            (c.onload = f.bind(null, c.onload)),
            s && document.head.appendChild(c);
        }
      }),
      (i.r = (e) => {
        "undefined" != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(e, "__esModule", { value: !0 });
      }),
      (i.p =
        "https://wl-apps.yourwebsite.life/contact-form/2.1.561/components/ContactForm/"),
      (r = (e) =>
        new Promise((t, r) => {
          var n = i.miniCssF(e),
            o = i.p + n;
          if (
            ((e, t) => {
              for (
                var r = document.getElementsByTagName("link"), n = 0;
                n < r.length;
                n++
              ) {
                var o =
                  (i = r[n]).getAttribute("data-href") ||
                  i.getAttribute("href");
                if ("stylesheet" === i.rel && (o === e || o === t)) return i;
              }
              var a = document.getElementsByTagName("style");
              for (n = 0; n < a.length; n++) {
                var i;
                if ((o = (i = a[n]).getAttribute("data-href")) === e || o === t)
                  return i;
              }
            })(n, o)
          )
            return t();
          ((e, t, r, n) => {
            var o = document.createElement("link");
            (o.rel = "stylesheet"),
              (o.type = "text/css"),
              (o.onerror = o.onload =
                (a) => {
                  if (((o.onerror = o.onload = null), "load" === a.type)) r();
                  else {
                    var i = a && ("load" === a.type ? "missing" : a.type),
                      c = (a && a.target && a.target.href) || t,
                      s = new Error(
                        "Loading CSS chunk " + e + " failed.\n(" + c + ")"
                      );
                    (s.code = "CSS_CHUNK_LOAD_FAILED"),
                      (s.type = i),
                      (s.request = c),
                      o.parentNode.removeChild(o),
                      n(s);
                  }
                }),
              (o.href = t),
              document.head.appendChild(o);
          })(e, o, t, r);
        })),
      (n = { 179: 0 }),
      (i.f.miniCss = (e, t) => {
        n[e]
          ? t.push(n[e])
          : 0 !== n[e] &&
            { 122: 1 }[e] &&
            t.push(
              (n[e] = r(e).then(
                () => {
                  n[e] = 0;
                },
                (t) => {
                  throw (delete n[e], t);
                }
              ))
            );
      }),
      (() => {
        var e = { 179: 0 };
        i.f.j = (t, r) => {
          var n = i.o(e, t) ? e[t] : void 0;
          if (0 !== n)
            if (n) r.push(n[2]);
            else {
              var o = new Promise((r, o) => (n = e[t] = [r, o]));
              r.push((n[2] = o));
              var a = i.p + i.u(t),
                c = new Error();
              i.l(
                a,
                (r) => {
                  if (i.o(e, t) && (0 !== (n = e[t]) && (e[t] = void 0), n)) {
                    var o = r && ("load" === r.type ? "missing" : r.type),
                      a = r && r.target && r.target.src;
                    (c.message =
                      "Loading chunk " +
                      t +
                      " failed.\n(" +
                      o +
                      ": " +
                      a +
                      ")"),
                      (c.name = "ChunkLoadError"),
                      (c.type = o),
                      (c.request = a),
                      n[1](c);
                  }
                },
                "chunk-" + t,
                t
              );
            }
        };
        var t = (t, r) => {
            var n,
              o,
              [a, c, s] = r,
              u = 0;
            if (a.some((t) => 0 !== e[t])) {
              for (n in c) i.o(c, n) && (i.m[n] = c[n]);
              s && s(i);
            }
            for (t && t(r); u < a.length; u++)
              (o = a[u]), i.o(e, o) && e[o] && e[o][0](), (e[o] = 0);
          },
          r = (self.webpackChunkcontact_form =
            self.webpackChunkcontact_form || []);
        r.forEach(t.bind(null, 0)), (r.push = t.bind(null, r.push.bind(r)));
      })(),
      (() => {
        var e = i(1053);
        function t() {
          return (
            (t =
              Object.assign ||
              function (e) {
                for (var t = 1; t < arguments.length; t++) {
                  var r = arguments[t];
                  for (var n in r)
                    Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                }
                return e;
              }),
            t.apply(this, arguments)
          );
        }
        var r = { ContactForm: null },
          n = function (e) {
            var t =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : 100,
              r =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : 3e4;
            return new Promise(function (n, o) {
              var a,
                i = new Date();
              a = setTimeout(function c() {
                if (e()) return clearTimeout(a), void n();
                +new Date() - i > r ? o() : (a = setTimeout(c, t));
              }, t);
            });
          },
          o = function (e) {
            var t = {};
            if (e.hasAttributes())
              for (var r = e.attributes, n = r.length - 1; n >= 0; n--) {
                var o = r[n],
                  a = o.name,
                  i = o.value;
                t[a] = i;
              }
            return t;
          },
          a = null;
        a = new IntersectionObserver(
          function (i) {
            i.forEach(function (i) {
              if (i.isIntersecting) {
                var c = i.target;
                a.unobserve(c),
                  n(function () {
                    return r.ContactForm;
                  }).then(function () {
                    return (function (n) {
                      var a = n.dataset,
                        i = a.hydrate;
                      if (!a.rendered)
                        try {
                          var c = JSON.parse(i);
                          if (c.iconEnabled) {
                            var s = n.querySelector("[data-role=icon]");
                            s &&
                              Object.assign(c, {
                                iconHtml: s.innerHTML,
                                iconAttributes: o(s),
                              });
                          }
                          var u = n.querySelector(
                              '[data-role="success-message"]'
                            ),
                            l = n.querySelector('[data-role="error-message"]'),
                            d = u.innerHTML || "",
                            f = l.innerHTML || "",
                            p = r.ContactForm;
                          window.ReactDOM.hydrate(
                            e.createElement(
                              p,
                              t({}, c, { successMessage: d, errorMessage: f })
                            ),
                            n
                          ),
                            (n.dataset.rendered = !0);
                        } catch (e) {
                          console.error(e);
                        }
                    })(c);
                  });
              }
            });
          },
          { rootMargin: "100px" }
        );
        var c = function (e) {
          for (
            var t = e.querySelectorAll("[data-app=contact-form]"), r = 0;
            r < t.length;
            ++r
          ) {
            var n = t[r];
            a.observe(n);
          }
        };
        n(function () {
          return window.loadReactDOM;
        })
          .then(window.loadReactDOM)
          .then(function () {
            return Promise.all([i.e(791), i.e(122)]).then(i.bind(i, 5403));
          })
          .then(function (e) {
            (r.ContactForm = e.ContactForm), c(document);
          }),
          n(function () {
            return window.registerAppComponentInitializer;
          })
            .then(function () {
              return window.registerAppComponentInitializer(c);
            })
            .catch(function () {
              return console.log(
                "window.registerAppComponentInitializer not found"
              );
            });
      })(),
      {}
    );
  })()
);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmlldy5qcyIsIm1hcHBpbmdzIjoiQUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL2NvbnRhY3QtZm9ybS93ZWJwYWNrL3VuaXZlcnNhbE1vZHVsZURlZmluaXRpb24iXSwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIHdlYnBhY2tVbml2ZXJzYWxNb2R1bGVEZWZpbml0aW9uKHJvb3QsIGZhY3RvcnkpIHtcblx0aWYodHlwZW9mIGV4cG9ydHMgPT09ICdvYmplY3QnICYmIHR5cGVvZiBtb2R1bGUgPT09ICdvYmplY3QnKVxuXHRcdG1vZHVsZS5leHBvcnRzID0gZmFjdG9yeSgpO1xuXHRlbHNlIGlmKHR5cGVvZiBkZWZpbmUgPT09ICdmdW5jdGlvbicgJiYgZGVmaW5lLmFtZClcblx0XHRkZWZpbmUoW10sIGZhY3RvcnkpO1xuXHRlbHNlIHtcblx0XHR2YXIgYSA9IGZhY3RvcnkoKTtcblx0XHRmb3IodmFyIGkgaW4gYSkgKHR5cGVvZiBleHBvcnRzID09PSAnb2JqZWN0JyA/IGV4cG9ydHMgOiByb290KVtpXSA9IGFbaV07XG5cdH1cbn0pKHNlbGYsICgpID0+IHtcbnJldHVybiAiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=
