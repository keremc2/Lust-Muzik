"use strict";
(self.webpackChunkcontact_form = self.webpackChunkcontact_form || []).push([
  [122],
  {
    5403: (e, t, r) => {
      function n(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function o(e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? n(Object(r), !0).forEach(function (t) {
                a(e, t, r[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
            : n(Object(r)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(r, t)
                );
              });
        }
        return e;
      }
      function a(e, t, r) {
        return (
          t in e
            ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = r),
          e
        );
      }
      function i(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n;
      }
      r.r(t), r.d(t, { ContactForm: () => Jt }), r(8023);
      var c = function (e) {
          return e ? e.trim() : "";
        },
        l = function () {
          return (
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ""
          )
            .substring(1)
            .split("&")
            .reduce(function (e, t) {
              var r,
                n,
                c =
                  ((r = t.split("=")),
                  (n = 2),
                  (function (e) {
                    if (Array.isArray(e)) return e;
                  })(r) ||
                    (function (e, t) {
                      var r =
                        null == e
                          ? null
                          : ("undefined" != typeof Symbol &&
                              e[Symbol.iterator]) ||
                            e["@@iterator"];
                      if (null != r) {
                        var n,
                          o,
                          a = [],
                          i = !0,
                          c = !1;
                        try {
                          for (
                            r = r.call(e);
                            !(i = (n = r.next()).done) &&
                            (a.push(n.value), !t || a.length !== t);
                            i = !0
                          );
                        } catch (e) {
                          (c = !0), (o = e);
                        } finally {
                          try {
                            i || null == r.return || r.return();
                          } finally {
                            if (c) throw o;
                          }
                        }
                        return a;
                      }
                    })(r, n) ||
                    (function (e, t) {
                      if (e) {
                        if ("string" == typeof e) return i(e, t);
                        var r = Object.prototype.toString.call(e).slice(8, -1);
                        return (
                          "Object" === r &&
                            e.constructor &&
                            (r = e.constructor.name),
                          "Map" === r || "Set" === r
                            ? Array.from(e)
                            : "Arguments" === r ||
                              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
                            ? i(e, t)
                            : void 0
                        );
                      }
                    })(r, n) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                      );
                    })()),
                l = c[0],
                s = c[1];
              return o(o({}, e), {}, a({}, l, s));
            }, {});
        };
      function s(e, t, r, n, o, a, i) {
        try {
          var c = e[a](i),
            l = c.value;
        } catch (e) {
          return void r(e);
        }
        c.done ? t(l) : Promise.resolve(l).then(n, o);
      }
      function u(e) {
        return function () {
          var t = this,
            r = arguments;
          return new Promise(function (n, o) {
            var a = e.apply(t, r);
            function i(e) {
              s(a, n, o, i, c, "next", e);
            }
            function c(e) {
              s(a, n, o, i, c, "throw", e);
            }
            i(void 0);
          });
        };
      }
      var f = function (e) {
          var t = new Headers({
            "Content-Type": "application/json",
            "App-Token": e,
          });
          return fetch(
            "".concat(
              "https://us-central1-weblium-contact-form-app.cloudfunctions.net",
              "/app/recaptcha/connection"
            ),
            { headers: t, method: "GET" }
          )
            .then(function (e) {
              return e.json();
            })
            .then(function (e) {
              return e.connection;
            })
            .catch(function (e) {
              console.error(e);
            });
        },
        d = function (e) {
          if (e) {
            var t = document.createElement("script");
            (t.src = "https://www.google.com/recaptcha/api.js?render=".concat(
              e
            )),
              document.head.appendChild(t);
          }
        },
        p = function (e, t) {
          "undefined" == typeof grecaptcha && (grecaptcha = {}),
            grecaptcha.ready(
              u(
                regeneratorRuntime.mark(function r() {
                  var n;
                  return regeneratorRuntime.wrap(function (r) {
                    for (;;)
                      switch ((r.prev = r.next)) {
                        case 0:
                          return (
                            (r.next = 2),
                            grecaptcha.execute(t, { action: "submit" })
                          );
                        case 2:
                          return (
                            (n = r.sent),
                            (document.getElementById(
                              "recaptchaResponse"
                            ).value = n),
                            (r.next = 7),
                            e(n)
                          );
                        case 7:
                        case "end":
                          return r.stop();
                      }
                  }, r);
                })
              )
            );
        };
      var m = r(1053),
        h = r(1341),
        b = function (e) {
          var t = e.title,
            r = e.id,
            n = e.name,
            o = e.required,
            a = e.onChange,
            i = e.className,
            l = e.customColors,
            s = e.value,
            u = e.link,
            f = e.isMultipleGroup;
          return m.createElement(
            "div",
            { className: "w-form__multiple-item" },
            m.createElement(
              "label",
              {
                className: h("w-checkbox", i),
                id: "".concat(r, "-label"),
                style: { color: l.text },
              },
              m.createElement("input", {
                type: "checkbox",
                name: n,
                onChange: a,
                id: c(r),
                value: t,
                required: o,
                checked: Boolean(s[r]) || "Yes" === s,
                className: "w-checkbox__input",
              }),
              m.createElement(
                "span",
                { className: "w-checkbox__mask", "aria-hidden": "true" },
                m.createElement(
                  "svg",
                  { viewBox: "0 0 11 8", fill: "none" },
                  m.createElement("path", {
                    d: "M1 4l3 3 6-6",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                  })
                )
              ),
              m.createElement(
                "span",
                { className: "w-checkbox__content" },
                u.active && "" !== u.value
                  ? m.createElement(
                      "a",
                      {
                        href: u.value,
                        className: "ui-link",
                        style: { color: l.text },
                        target: "_blank",
                        rel: "noopener noreferrer",
                      },
                      t
                    )
                  : t
              ),
              o &&
                t &&
                !f &&
                m.createElement(
                  "span",
                  { title: "Required field", className: "required-mark" },
                  "*"
                )
            )
          );
        };
      b.defaultProps = {
        name: void 0,
        required: !1,
        title: "",
        className: "",
        customColors: {},
        value: {},
        link: { value: "", active: !1 },
      };
      const y = b;
      var v = r(3445),
        g = r.n(v),
        w = r(1053),
        O = r(1341);
      function E(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function j(e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? E(Object(r), !0).forEach(function (t) {
                S(e, t, r[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
            : E(Object(r)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(r, t)
                );
              });
        }
        return e;
      }
      function S(e, t, r) {
        return (
          t in e
            ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = r),
          e
        );
      }
      function C(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n;
      }
      var P = w.useState,
        k = function (e) {
          var t,
            r,
            n = e.title,
            o = e.description,
            a = e.placeholder,
            i = e.items,
            l = e.id,
            s = e.required,
            u = e.onChange,
            f = e.fieldClassName,
            d = e.labelClassName,
            p = e.buttonSize,
            m = e.descriptionClassName,
            h = e.customColors,
            b = e.typography,
            y = e.colors,
            v = e.value,
            E = e.fieldStyle,
            _ = e.theme,
            S =
              ((t = P(!0)),
              (r = 2),
              (function (e) {
                if (Array.isArray(e)) return e;
              })(t) ||
                (function (e, t) {
                  var r =
                    null == e
                      ? null
                      : ("undefined" != typeof Symbol && e[Symbol.iterator]) ||
                        e["@@iterator"];
                  if (null != r) {
                    var n,
                      o,
                      a = [],
                      i = !0,
                      c = !1;
                    try {
                      for (
                        r = r.call(e);
                        !(i = (n = r.next()).done) &&
                        (a.push(n.value), !t || a.length !== t);
                        i = !0
                      );
                    } catch (e) {
                      (c = !0), (o = e);
                    } finally {
                      try {
                        i || null == r.return || r.return();
                      } finally {
                        if (c) throw o;
                      }
                    }
                    return a;
                  }
                })(t, r) ||
                (function (e, t) {
                  if (e) {
                    if ("string" == typeof e) return C(e, t);
                    var r = Object.prototype.toString.call(e).slice(8, -1);
                    return (
                      "Object" === r &&
                        e.constructor &&
                        (r = e.constructor.name),
                      "Map" === r || "Set" === r
                        ? Array.from(e)
                        : "Arguments" === r ||
                          /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
                        ? C(e, t)
                        : void 0
                    );
                  }
                })(t, r) ||
                (function () {
                  throw new TypeError(
                    "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                  );
                })()),
            k = (S[0], S[1]),
            N = function () {
              return (
                (h.text && g()(h.text).setAlpha(0.54).toRgbString()) ||
                ("light" === _
                  ? g()(b.text.color[0]).setAlpha(0.54).toRgbString()
                  : g()(b.text.color[1] || b.text.color[0])
                      .setAlpha(0.54)
                      .toRgbString())
              );
            };
          return w.createElement(
            "div",
            { className: O("w-form__field", f) },
            n &&
              w.createElement(
                "label",
                {
                  className: O("w-form__label", d),
                  htmlFor: c(l),
                  style: { color: h.text },
                },
                n,
                s &&
                  n &&
                  w.createElement(
                    "span",
                    { title: "Required field", className: "required-mark" },
                    "*"
                  )
              ),
            o.active &&
              w.createElement(
                "small",
                {
                  className: O("w-form__description", m),
                  style: { color: h.description },
                },
                o.value
              ),
            w.createElement(
              "div",
              { className: "w-relative-wrapper" },
              w.createElement(
                "select",
                {
                  onChange: function (e) {
                    "" === e.target.value && (k(!0), u(e)),
                      "" !== e.target.value && (k(!1), u(e));
                  },
                  id: l,
                  required: s,
                  className: O(
                    "w-form__input w-form__input--select",
                    "ui-input ui-input--size-".concat(p)
                  ),
                  style: j(
                    j({}, E.style),
                    {},
                    {
                      backgroundColor:
                        h.fill ||
                        ("light" === _
                          ? g()(y["dark-shade-color"])
                              .setAlpha(0.12)
                              .toRgbString()
                          : g()(y["light-shade-color"])
                              .setAlpha(0.24)
                              .toRgbString()),
                      borderColor:
                        h.border ||
                        y[
                          "".concat(
                            "light" === _ ? "dark" : "light",
                            "-accent-color"
                          )
                        ],
                      color: N(),
                    }
                  ),
                },
                w.createElement(
                  "option",
                  {
                    selected: !v,
                    disabled: !0,
                    hidden: !0,
                    key: "option-default",
                    value: "",
                  },
                  a
                ),
                i.map(function (e) {
                  return (
                    e.title &&
                    w.createElement(
                      "option",
                      {
                        key: "option-".concat(e.id),
                        value: e.title,
                        selected: v === e.title,
                      },
                      e.title
                    )
                  );
                })
              ),
              w.createElement(
                "span",
                {
                  "aria-hidden": "true",
                  className: "w-select-arrow",
                  style: { color: N() },
                },
                w.createElement(
                  "svg",
                  { viewBox: "0 0 14 8" },
                  w.createElement("path", {
                    d: "M7.7 7.7l6-6c.4-.4.4-1 0-1.4-.4-.4-1-.4-1.4 0L7 5.6 1.7.299999c-.4-.4-1-.4-1.4 0-.2.2-.3.4-.3.7C0 1.3.1 1.5.3 1.7l6 6c.2.2.5.3.7.3.3 0 .5-.1.7-.3z",
                  })
                )
              )
            )
          );
        };
      k.defaultProps = {
        required: !1,
        title: "",
        description: { value: "", active: !1 },
        placeholder: "Type placeholder text",
        fieldClassName: "",
        labelClassName: "",
        descriptionClassName: "",
        customColors: {},
      };
      const N = k;
      var x = r(5556),
        R = r(1053);
      const D = function () {
        return R.createElement(
          "svg",
          { viewBox: "0 0 17 17" },
          R.createElement("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            d: "M8.9003.199954c-.2-.2666057-.59993-.2666053-.79993.000001L5.10018 4.19927c-.24727.32961-.01209.80005.39996.80005H7.5v8.99998h2V4.99932h2.0005c.4121 0 .6473-.47044.4-.80005L8.9003.199954zM15.5 8.99932v5.49658c0 .8011-.2 1.0041-1 1.0041h-12c-.8 0-1-.203-1-1.0041V8.99932H0v5.49658c0 1.4019 1.1 2.5034 2.5 2.5034h12c1.4 0 2.5-1.1015 2.5-2.5034V8.99932h-1.5z",
          })
        );
      };
      var A = r(1053),
        M = r(1341),
        q = r(6568);
      function I(e) {
        return (
          (I =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (e) {
                  return typeof e;
                }
              : function (e) {
                  return e &&
                    "function" == typeof Symbol &&
                    e.constructor === Symbol &&
                    e !== Symbol.prototype
                    ? "symbol"
                    : typeof e;
                }),
          I(e)
        );
      }
      var T = ["autoComplete", "style"],
        B = [
          "id",
          "title",
          "required",
          "exactValue",
          "defaultValue",
          "hidden",
          "fieldClassName",
          "labelClassName",
          "fieldStyle",
          "customColors",
          "theme",
          "colors",
          "urlParam",
          "description",
        ];
      function F(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function L(e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? F(Object(r), !0).forEach(function (t) {
                W(e, t, r[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
            : F(Object(r)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(r, t)
                );
              });
        }
        return e;
      }
      function z() {
        return (
          (z =
            Object.assign ||
            function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var r = arguments[t];
                for (var n in r)
                  Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
              }
              return e;
            }),
          z.apply(this, arguments)
        );
      }
      function H(e, t) {
        if (null == e) return {};
        var r,
          n,
          o = (function (e, t) {
            if (null == e) return {};
            var r,
              n,
              o = {},
              a = Object.keys(e);
            for (n = 0; n < a.length; n++)
              (r = a[n]), t.indexOf(r) >= 0 || (o[r] = e[r]);
            return o;
          })(e, t);
        if (Object.getOwnPropertySymbols) {
          var a = Object.getOwnPropertySymbols(e);
          for (n = 0; n < a.length; n++)
            (r = a[n]),
              t.indexOf(r) >= 0 ||
                (Object.prototype.propertyIsEnumerable.call(e, r) &&
                  (o[r] = e[r]));
        }
        return o;
      }
      function V(e, t) {
        for (var r = 0; r < t.length; r++) {
          var n = t[r];
          (n.enumerable = n.enumerable || !1),
            (n.configurable = !0),
            "value" in n && (n.writable = !0),
            Object.defineProperty(e, n.key, n);
        }
      }
      function U(e, t) {
        return (
          (U =
            Object.setPrototypeOf ||
            function (e, t) {
              return (e.__proto__ = t), e;
            }),
          U(e, t)
        );
      }
      function $(e) {
        if (void 0 === e)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return e;
      }
      function X(e) {
        return (
          (X = Object.setPrototypeOf
            ? Object.getPrototypeOf
            : function (e) {
                return e.__proto__ || Object.getPrototypeOf(e);
              }),
          X(e)
        );
      }
      function W(e, t, r) {
        return (
          t in e
            ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = r),
          e
        );
      }
      var Y = ["text", "email", "tel"],
        G = A.Fragment,
        J = function (e) {
          var t = e.title,
            r = e.required,
            n = e.color;
          return A.createElement(
            "span",
            { style: { color: n } },
            t,
            r &&
              t &&
              A.createElement(
                "span",
                { title: "Required field", className: "required-mark" },
                "*"
              )
          );
        },
        K = (function (e) {
          !(function (e, t) {
            if ("function" != typeof t && null !== t)
              throw new TypeError(
                "Super expression must either be null or a function"
              );
            (e.prototype = Object.create(t && t.prototype, {
              constructor: { value: e, writable: !0, configurable: !0 },
            })),
              t && U(e, t);
          })(i, e);
          var t,
            r,
            n,
            o,
            a =
              ((n = i),
              (o = (function () {
                if ("undefined" == typeof Reflect || !Reflect.construct)
                  return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                  return (
                    Boolean.prototype.valueOf.call(
                      Reflect.construct(Boolean, [], function () {})
                    ),
                    !0
                  );
                } catch (e) {
                  return !1;
                }
              })()),
              function () {
                var e,
                  t = X(n);
                if (o) {
                  var r = X(this).constructor;
                  e = Reflect.construct(t, arguments, r);
                } else e = t.apply(this, arguments);
                return (function (e, t) {
                  if (t && ("object" === I(t) || "function" == typeof t))
                    return t;
                  if (void 0 !== t)
                    throw new TypeError(
                      "Derived constructors may only return object or undefined"
                    );
                  return $(e);
                })(this, e);
              });
          function i() {
            var e;
            !(function (e, t) {
              if (!(e instanceof t))
                throw new TypeError("Cannot call a class as a function");
            })(this, i);
            for (var t = arguments.length, r = new Array(t), n = 0; n < t; n++)
              r[n] = arguments[n];
            return (
              W($((e = a.call.apply(a, [this].concat(r)))), "state", {}),
              W($(e), "deleteFile", function (e) {
                return fetch(
                  ""
                    .concat(
                      "https://us-central1-weblium-contact-form-app.cloudfunctions.net",
                      "/file/delete/"
                    )
                    .concat(window.websiteId, "/")
                    .concat(e),
                  { method: "DELETE" }
                );
              }),
              W($(e), "parseId", function (e) {
                return e && _.first(e.split("/").reverse());
              }),
              W($(e), "handleSelectFiles", function (t) {
                if (
                  (e.setState({ error: !1, errorMessage: !1 }),
                  e.props.inSiteRender && t)
                )
                  try {
                    var r = t[0];
                    if (r.size / 1048576 > 100)
                      return void e.setState({
                        error: !0,
                        errorMessage:
                          "This file is too large. You can compress it to less than 100 MB or send it through other contact channels.",
                      });
                    var n = new FileReader();
                    (n.onload = function () {
                      return fetch(
                        ""
                          .concat(
                            "https://us-central1-weblium-contact-form-app.cloudfunctions.net",
                            "/file/upload/"
                          )
                          .concat(window.websiteId),
                        {
                          method: "POST",
                          headers: {
                            "Access-Control-Allow-Origin": "*",
                            "Content-Type": "application/octet-stream",
                            "Content-Disposition":
                              'attachment; filename="'.concat(
                                encodeURIComponent(r.path),
                                '"'
                              ),
                          },
                          body: n.result,
                        }
                      )
                        .then(function (e) {
                          return e.json();
                        })
                        .then(function (t) {
                          var n = t.data,
                            o = e.state.data && e.parseId(e.state.data.id);
                          o && e.deleteFile(o).catch(console.error),
                            e.props.onChange({
                              target: {
                                value: { url: n.url, fileName: r.name },
                              },
                            }),
                            e.setState({
                              loading: !1,
                              data: n,
                              fileName: r.name,
                            });
                        })
                        .catch(function (t) {
                          return e.setState({ error: t, loading: !1 });
                        });
                    }),
                      (n.onerror = function (t) {
                        return e.setState({ error: t, loading: !1 });
                      }),
                      e.setState({ loading: !0 }),
                      n.readAsArrayBuffer(r);
                  } catch (t) {
                    e.setState({ error: t, loading: !1 });
                  }
              }),
              e
            );
          }
          return (
            (t = i),
            (r = [
              {
                key: "componentWillMount",
                value: function () {
                  var e = this,
                    t = this.props.onFormReset;
                  t &&
                    (this.subscription = t(function () {
                      e.setState({ data: null, fileName: null });
                    }));
                },
              },
              {
                key: "componentWillUnmount",
                value: function () {
                  this.subscription && this.subscription.unsubscribe();
                },
              },
              {
                key: "render",
                value: function () {
                  var e = this.props,
                    t = e.id,
                    r = e.fieldClassName,
                    n = e.required,
                    o = e.placeholder,
                    a = e.clipIcon,
                    i = e.style.color,
                    c = this.state,
                    l = c.loading,
                    s = c.error,
                    u = c.data,
                    f = c.fileName,
                    d = c.errorMessage;
                  return A.createElement(
                    G,
                    null,
                    A.createElement(
                      "div",
                      {
                        className: M("w-form__input w-form__input--file", r),
                        style: { color: i },
                      },
                      A.createElement(
                        x.Z,
                        { onDrop: this.handleSelectFiles, multiple: !1 },
                        function (e) {
                          var r = e.getInputProps,
                            i = e.getRootProps,
                            c = r(),
                            l = (c.autoComplete, c.style, H(c, T));
                          return A.createElement(
                            "div",
                            z({}, i(), { className: "w-input-file" }),
                            a &&
                              A.createElement(
                                "div",
                                { className: "w-input-file__icon" },
                                A.createElement(D, null)
                              ),
                            A.createElement(
                              "input",
                              z({}, l, {
                                id: t,
                                className: M("w-input-file__input"),
                                required: n,
                                style: {
                                  top: 0,
                                  left: 0,
                                  height: "100%",
                                  width: "100%",
                                  position: "absolute",
                                  opacity: 0,
                                  margin: 0,
                                },
                              })
                            ),
                            A.createElement(
                              "div",
                              { className: "w-input-file__content" },
                              o || "Choose file"
                            )
                          );
                        }
                      )
                    ),
                    l &&
                      A.createElement(
                        "span",
                        { className: M("ui-text w-link") },
                        "Loading..."
                      ),
                    u &&
                      A.createElement(
                        "a",
                        {
                          href: u.url,
                          className: M("ui-text w-link w-input-file__filename"),
                          rel: "noopener noreferrer",
                          target: "_blank",
                        },
                        f
                      ),
                    s &&
                      A.createElement(
                        "p",
                        { className: "w-form__error-msg ui-text" },
                        d || "Something went wrong"
                      )
                  );
                },
              },
            ]) && V(t.prototype, r),
            i
          );
        })(A.Component);
      W(K, "propTypes", {
        id: q.string.isRequired,
        onChange: q.func.isRequired,
        fieldClassName: q.string,
        labelClassName: q.string,
        required: q.bool,
        buttonSize: q.string.isRequired,
        clipIcon: q.bool.isRequired,
        onFormReset: q.func.isRequired,
        placeholder: q.string,
        style: q.object,
        inSiteRender: q.bool,
      }),
        W(K, "defaultProps", {
          required: !1,
          fieldClassName: null,
          labelClassName: null,
          placeholder: null,
          style: {},
        });
      var Z = function (e) {
          var t = e.id,
            r = e.type,
            n = e.required,
            o = e.pattern,
            a = e.defaultValue,
            i = e.placeholder,
            c = e.onChange,
            s = e.urlParam,
            u = e.onInvalid,
            f = e.descriptionClassName,
            d = e.description,
            p = e.buttonSize,
            m = e.clipIcon,
            h = e.value,
            b = e.onFormReset,
            y = e.style,
            v = e.borderColor,
            w = e.fillColor,
            O = e.color,
            E = e.descriptionColor,
            _ = e.colors,
            j = e.theme,
            S = e.inSiteRender,
            C = function () {
              return (
                w ||
                ("light" === j
                  ? g()(_["dark-shade-color"]).setAlpha(0.12).toRgbString()
                  : g()(_["light-shade-color"]).setAlpha(0.24).toRgbString())
              );
            },
            P = {
              type: r,
              id: t,
              className: M(
                "w-form__input",
                "ui-input ui-input--size-".concat(p)
              ),
              placeholder: i,
              onChange: c,
              onInvalid: u,
              required: n,
              pattern: o,
              style: L(
                L({}, y),
                {},
                {
                  borderColor:
                    v ||
                    _[
                      "".concat(
                        "light" === j ? "dark" : "light",
                        "-accent-color"
                      )
                    ],
                  backgroundColor: C(),
                  color: O,
                  "--w-get-input-background-color": C(),
                  "--w-get-input-color": O,
                }
              ),
              value: h,
              inSiteRender: S,
            },
            k = A.useRef();
          return (
            A.useEffect(function () {
              if ((k.current && a && c(a), s)) {
                var e = l(window.location.search)[s];
                e && c(e);
              }
            }, []),
            A.useEffect(
              function () {
                S &&
                  k.current &&
                  Y.includes(P.type) &&
                  (k.current.maxLength = 2e3);
              },
              [S]
            ),
            A.createElement(
              G,
              null,
              d.active &&
                A.createElement(
                  "small",
                  {
                    className: M("w-form__description", f),
                    style: { color: E },
                  },
                  d.value
                ),
              "file" === r
                ? A.createElement(
                    K,
                    z(
                      {
                        description: d,
                        buttonSize: p,
                        clipIcon: m,
                        onFormReset: b,
                        placeholder: i,
                      },
                      P
                    )
                  )
                : A.createElement("input", z({}, P, { ref: k }))
            )
          );
        },
        Q = function (e) {
          var t = e.id,
            r = e.title,
            n = e.required,
            o = e.exactValue,
            a = e.defaultValue,
            i = e.hidden,
            c = e.fieldClassName,
            l = e.labelClassName,
            s = e.fieldStyle,
            u = e.customColors,
            f = e.theme,
            d = e.colors,
            p = e.urlParam,
            m = e.description,
            h = H(e, B),
            b = "string" == typeof m ? { value: m, active: !0 } : m,
            y = {};
          return (
            i && (y.display = "none"),
            A.createElement(
              "div",
              { className: M("w-form__field", c), style: y },
              r &&
                A.createElement(
                  "label",
                  { htmlFor: t, className: M("w-form__label", l) },
                  A.createElement(J, {
                    title: r,
                    required: n,
                    id: t,
                    color: u.text,
                  })
                ),
              A.createElement(
                Z,
                z(
                  {
                    urlParam: p,
                    defaultValue: a,
                    labelClassName: l,
                    required: n,
                    pattern: n && o ? "^".concat(o, "$") : void 0,
                    onInvalid:
                      n && o
                        ? function (e) {
                            try {
                              var t =
                                window.navigator.userLanguage ||
                                window.navigator.language;
                              e.target.value &&
                                (e.target.value !== o
                                  ? e.target.setCustomValidity(
                                      "ru" === t
                                        ? "Введенное значение неверное"
                                        : "Entered value is invalid"
                                    )
                                  : e.target.setCustomValidity(""));
                            } catch (e) {
                              console.warn("onInvalidValue", e);
                            }
                          }
                        : void 0,
                    style: s.style,
                    borderColor: u.border,
                    fillColor: u.fill,
                    color: u.text,
                    description: b,
                    descriptionColor: u.description,
                    id: t,
                    fieldClassName: c,
                    theme: f,
                    colors: d,
                  },
                  h
                )
              )
            )
          );
        };
      (J.defaultProps = { title: "", required: !1 }),
        (Z.defaultProps = {
          placeholder: "",
          required: !1,
          description: { value: "", active: !1 },
          fieldClassName: "",
          labelClassName: "",
          descriptionClassName: "",
          value: "",
          onFormReset: null,
          style: {},
        }),
        (Q.defaultProps = {
          title: "",
          required: !1,
          fieldClassName: "",
          labelClassName: "",
          customColors: {},
        });
      const ee = Q;
      var te = r(1053),
        re = function (e) {
          var t = e.title,
            r = e.id,
            n = e.name,
            o = e.onChange,
            a = e.customColors,
            i = e.value,
            l = e.required;
          return te.createElement(
            "div",
            { className: "w-form__multiple-item" },
            te.createElement(
              "label",
              { className: "w-radio-button", style: { color: a.text } },
              te.createElement("input", {
                type: "radio",
                id: c(r),
                name: n,
                required: l,
                checked: i === t,
                value: t,
                onChange: o,
                className: "w-radio-button__input",
              }),
              te.createElement("span", {
                className: "w-radio-button__mask",
                "aria-hidden": "true",
              }),
              te.createElement(
                "span",
                { className: "w-radio-button__content" },
                t
              )
            )
          );
        };
      re.defaultProps = { customColors: {} };
      const ne = re;
      var oe = r(1053),
        ae = r(1341);
      function ie(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function ce(e, t, r) {
        return (
          t in e
            ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = r),
          e
        );
      }
      function le(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n;
      }
      var se = function (e) {
        var t,
          r,
          n = e.title,
          o = e.description,
          a = e.id,
          i = e.value,
          c = e.items,
          l = e.required,
          s = e.onChange,
          u = e.fieldClassName,
          f = e.labelClassName,
          d = e.descriptionClassName,
          p = e.customColors,
          m = e.type,
          h = e.sendingMessage,
          b = { checkbox: y, radioButton: ne },
          v = oe.useRef(null),
          g =
            ((t = oe.useState(null)),
            (r = 2),
            (function (e) {
              if (Array.isArray(e)) return e;
            })(t) ||
              (function (e, t) {
                var r =
                  null == e
                    ? null
                    : ("undefined" != typeof Symbol && e[Symbol.iterator]) ||
                      e["@@iterator"];
                if (null != r) {
                  var n,
                    o,
                    a = [],
                    i = !0,
                    c = !1;
                  try {
                    for (
                      r = r.call(e);
                      !(i = (n = r.next()).done) &&
                      (a.push(n.value), !t || a.length !== t);
                      i = !0
                    );
                  } catch (e) {
                    (c = !0), (o = e);
                  } finally {
                    try {
                      i || null == r.return || r.return();
                    } finally {
                      if (c) throw o;
                    }
                  }
                  return a;
                }
              })(t, r) ||
              (function (e, t) {
                if (e) {
                  if ("string" == typeof e) return le(e, t);
                  var r = Object.prototype.toString.call(e).slice(8, -1);
                  return (
                    "Object" === r && e.constructor && (r = e.constructor.name),
                    "Map" === r || "Set" === r
                      ? Array.from(e)
                      : "Arguments" === r ||
                        /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
                      ? le(e, t)
                      : void 0
                  );
                }
              })(t, r) ||
              (function () {
                throw new TypeError(
                  "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                );
              })()),
          w = g[0],
          O = g[1],
          E = oe.useCallback(
            function () {
              l &&
                "checkbox" === m &&
                O(
                  !v.current.querySelectorAll("input[type=checkbox]:checked")
                    .length
                );
            },
            [v, l, m]
          ),
          _ = oe.useCallback(
            function (e) {
              return E(), s(e);
            },
            [s, E]
          );
        return (
          oe.useLayoutEffect(
            function () {
              l && "checkbox" === m && O(!0);
            },
            [h]
          ),
          oe.createElement(
            "div",
            { className: ae("w-form__field", u) },
            n &&
              oe.createElement(
                "p",
                { className: ae("w-form__label", f), style: { color: p.text } },
                n,
                l &&
                  n &&
                  oe.createElement(
                    "span",
                    { title: "Required field", className: "required-mark" },
                    "*"
                  )
              ),
            o.active &&
              oe.createElement(
                "small",
                {
                  className: ae("w-form__description", d),
                  style: { color: p.description },
                },
                o.value
              ),
            oe.createElement(
              "div",
              { className: "w-form__multiple-group", ref: v },
              c.map(function (e) {
                return (
                  e.title &&
                  oe.createElement(
                    b[m],
                    (function (e) {
                      for (var t = 1; t < arguments.length; t++) {
                        var r = null != arguments[t] ? arguments[t] : {};
                        t % 2
                          ? ie(Object(r), !0).forEach(function (t) {
                              ce(e, t, r[t]);
                            })
                          : Object.getOwnPropertyDescriptors
                          ? Object.defineProperties(
                              e,
                              Object.getOwnPropertyDescriptors(r)
                            )
                          : ie(Object(r)).forEach(function (t) {
                              Object.defineProperty(
                                e,
                                t,
                                Object.getOwnPropertyDescriptor(r, t)
                              );
                            });
                      }
                      return e;
                    })(
                      {
                        key: e.id,
                        name: a,
                        isMultipleGroup: !0,
                        onChange: _,
                        customColors: p,
                        required: "checkbox" === m ? w : l,
                        value: i,
                      },
                      e
                    )
                  )
                );
              })
            )
          )
        );
      };
      se.defaultProps = {
        required: !1,
        fieldClassName: "",
        items: [],
        title: "",
        description: { value: "", active: !1 },
        labelClassName: "",
        descriptionClassName: "",
        customColors: {},
        type: "radioButton",
      };
      const ue = se;
      var fe = r(1053),
        de = r(1341);
      function pe(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function me(e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? pe(Object(r), !0).forEach(function (t) {
                he(e, t, r[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
            : pe(Object(r)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(r, t)
                );
              });
        }
        return e;
      }
      function he(e, t, r) {
        return (
          t in e
            ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = r),
          e
        );
      }
      var be = function (e) {
        var t = e.title,
          r = e.id,
          n = e.placeholder,
          o = e.required,
          a = e.description,
          i = e.onChange,
          l = e.fieldClassName,
          s = e.buttonSize,
          u = e.labelClassName,
          f = e.descriptionClassName,
          d = e.fieldStyle.style,
          p = void 0 === d ? {} : d,
          m = e.customColors,
          h = e.theme,
          b = e.colors,
          y = e.value,
          v = e.inSiteRender,
          w = e.hidden,
          O = fe.useRef();
        return (
          fe.useEffect(
            function () {
              v && (O.current.maxLength = 2e3);
            },
            [v]
          ),
          fe.createElement(
            "div",
            {
              className: de("w-form__field", l),
              style: me({}, w && { display: "none" }),
            },
            t &&
              fe.createElement(
                "label",
                {
                  htmlFor: c(r),
                  className: de("w-form__label", u),
                  style: { color: m.text },
                },
                t,
                o &&
                  t &&
                  fe.createElement(
                    "span",
                    { title: "Required field", className: "required-mark" },
                    "*"
                  )
              ),
            a.active &&
              fe.createElement(
                "small",
                {
                  className: de("w-form__description", f),
                  style: { color: m.description },
                },
                a.value
              ),
            fe.createElement("textarea", {
              id: r,
              ref: O,
              placeholder: n,
              onChange: i,
              value: y,
              style: me(
                me({}, p),
                {},
                {
                  borderColor:
                    m.border ||
                    b[
                      "".concat(
                        "light" === h ? "dark" : "light",
                        "-accent-color"
                      )
                    ],
                  backgroundColor:
                    m.fill ||
                    ("light" === h
                      ? g()(b["dark-shade-color"]).setAlpha(0.12).toRgbString()
                      : g()(b["light-shade-color"])
                          .setAlpha(0.24)
                          .toRgbString()),
                  color: m.text,
                }
              ),
              className: de(
                "w-form__input",
                "w-form__input--textarea",
                "ui-input ui-input--size-".concat(s)
              ),
              required: o,
            })
          )
        );
      };
      be.defaultProps = {
        required: !1,
        title: "",
        description: { value: "", active: !1 },
        placeholder: "",
        fieldClassName: "",
        labelClassName: "",
        descriptionClassName: "",
      };
      const ye = be;
      var ve = r(1266),
        ge = r.n(ve),
        we = r(1320),
        Oe = r(1053);
      const Ee = function (e) {
        var t = e.children,
          r = e.className;
        return Oe.createElement(ve.CalendarContainer, { className: r }, t);
      };
      var _e = r(3107),
        je = r.n(_e),
        Se = r(6309);
      function Ce(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n;
      }
      var Pe = r(1053),
        ke = Pe.useEffect,
        Ne = Pe.useState;
      const xe = {
        container: "container_2X3",
        container__inner: "container__inner_XXn",
        "fade-up-in": "fade-up-in_lqB",
        fadeUpIn: "fade-up-in_lqB",
        "fade-up-entering": "fade-up-entering_2_l",
        fadeUpEntering: "fade-up-entering_2_l",
        "fade-up-entered": "fade-up-entered_2PU",
        fadeUpEntered: "fade-up-entered_2PU",
        "fade-up-out": "fade-up-out_1RI",
        fadeUpOut: "fade-up-out_1RI",
        "fade-up-exiting": "fade-up-exiting_2ss",
        fadeUpExiting: "fade-up-exiting_2ss",
        "fade-up-exited": "fade-up-exited_1Lh",
        fadeUpExited: "fade-up-exited_1Lh",
        "fade-down-in": "fade-down-in_6ST",
        fadeDownIn: "fade-down-in_6ST",
        "fade-down-entering": "fade-down-entering_MRH",
        fadeDownEntering: "fade-down-entering_MRH",
        "fade-down-entered": "fade-down-entered_1Ne",
        fadeDownEntered: "fade-down-entered_1Ne",
        "fade-down-exiting": "fade-down-exiting_3uX",
        fadeDownExiting: "fade-down-exiting_3uX",
        "fade-down-out": "fade-down-out_2B4",
        fadeDownOut: "fade-down-out_2B4",
      };
      var Re = r(1053),
        De = r(1341),
        Ae = Re,
        Me = Ae.useEffect,
        qe = Ae.useRef;
      const Ie = function (e) {
        var t,
          r = e.children,
          n = e.btnRef,
          o = e.handleClose,
          a = void 0 === o ? function () {} : o,
          i = e.top,
          c = e.left,
          l = e.upRender,
          s = e.state,
          u = e.dropContainerRef;
        !(function () {
          var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : [],
            t = arguments.length > 1 ? arguments[1] : void 0;
          ke(function () {
            var r = function (r) {
              e.some(function (e) {
                return e.current.contains(r.target);
              }) || t(r);
            };
            return (
              document.addEventListener("mousedown", r),
              document.addEventListener("touchstart", r),
              document.addEventListener("scroll", r),
              document.addEventListener("wheel", r),
              function () {
                document.removeEventListener("mousedown", r),
                  document.removeEventListener("touchstart", r),
                  document.removeEventListener("scroll", r),
                  document.removeEventListener("wheel", r);
              }
            );
          }, []);
        })([u, n], a),
          (t = a),
          ke(function () {
            var e = function (e) {
              t(e);
            };
            return (
              window.addEventListener("resize", e),
              function () {
                return window.removeEventListener("resize", e);
              }
            );
          }, []);
        var f,
          d,
          p,
          m,
          h,
          b,
          y,
          v,
          g =
            ((f = "Escape"),
            (y = Ne(!1)),
            (v = 2),
            (p = (d =
              (function (e) {
                if (Array.isArray(e)) return e;
              })(y) ||
              (function (e, t) {
                var r =
                  null == e
                    ? null
                    : ("undefined" != typeof Symbol && e[Symbol.iterator]) ||
                      e["@@iterator"];
                if (null != r) {
                  var n,
                    o,
                    a = [],
                    i = !0,
                    c = !1;
                  try {
                    for (
                      r = r.call(e);
                      !(i = (n = r.next()).done) &&
                      (a.push(n.value), !t || a.length !== t);
                      i = !0
                    );
                  } catch (e) {
                    (c = !0), (o = e);
                  } finally {
                    try {
                      i || null == r.return || r.return();
                    } finally {
                      if (c) throw o;
                    }
                  }
                  return a;
                }
              })(y, v) ||
              (function (e, t) {
                if (e) {
                  if ("string" == typeof e) return Ce(e, t);
                  var r = Object.prototype.toString.call(e).slice(8, -1);
                  return (
                    "Object" === r && e.constructor && (r = e.constructor.name),
                    "Map" === r || "Set" === r
                      ? Array.from(e)
                      : "Arguments" === r ||
                        /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
                      ? Ce(e, t)
                      : void 0
                  );
                }
              })(y, v) ||
              (function () {
                throw new TypeError(
                  "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                );
              })())[0]),
            (m = d[1]),
            (h = function (e) {
              e.key === f && m(!0);
            }),
            (b = function (e) {
              e.key === f && m(!1);
            }),
            ke(function () {
              return (
                window.addEventListener("keydown", h),
                window.addEventListener("keyup", b),
                function () {
                  window.removeEventListener("keydown", h),
                    window.removeEventListener("keyup", b);
                }
              );
            }, []),
            p),
          w = qe();
        return (
          Me(
            function () {
              if ("entered" === s)
                return function () {
                  n && n.current && n.current.focus();
                };
            },
            [s]
          ),
          Me(
            function () {
              g && a();
            },
            [g]
          ),
          Re.createElement(
            "div",
            {
              style: { top: i, left: c, right: "auto" },
              className: De(
                xe.container,
                l ? xe["fade-down-".concat(s)] : xe["fade-up-".concat(s)],
                "w-block-wrapper"
              ),
              ref: u,
            },
            Re.createElement(
              "div",
              { ref: w, className: De(xe.container__inner, "w-date-picker") },
              r
            )
          )
        );
      };
      var Te = r(1053);
      function Be(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function Fe(e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? Be(Object(r), !0).forEach(function (t) {
                Le(e, t, r[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
            : Be(Object(r)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(r, t)
                );
              });
        }
        return e;
      }
      function Le(e, t, r) {
        return (
          t in e
            ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = r),
          e
        );
      }
      function ze(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n;
      }
      var He = Te,
        Ve = He.useState,
        Ue = He.useRef,
        $e = function (e) {
          var t,
            r,
            n = Ue(),
            o =
              ((t = Ve({ top: 0, left: 0, upRender: !1 })),
              (r = 2),
              (function (e) {
                if (Array.isArray(e)) return e;
              })(t) ||
                (function (e, t) {
                  var r =
                    null == e
                      ? null
                      : ("undefined" != typeof Symbol && e[Symbol.iterator]) ||
                        e["@@iterator"];
                  if (null != r) {
                    var n,
                      o,
                      a = [],
                      i = !0,
                      c = !1;
                    try {
                      for (
                        r = r.call(e);
                        !(i = (n = r.next()).done) &&
                        (a.push(n.value), !t || a.length !== t);
                        i = !0
                      );
                    } catch (e) {
                      (c = !0), (o = e);
                    } finally {
                      try {
                        i || null == r.return || r.return();
                      } finally {
                        if (c) throw o;
                      }
                    }
                    return a;
                  }
                })(t, r) ||
                (function (e, t) {
                  if (e) {
                    if ("string" == typeof e) return ze(e, t);
                    var r = Object.prototype.toString.call(e).slice(8, -1);
                    return (
                      "Object" === r &&
                        e.constructor &&
                        (r = e.constructor.name),
                      "Map" === r || "Set" === r
                        ? Array.from(e)
                        : "Arguments" === r ||
                          /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
                        ? ze(e, t)
                        : void 0
                    );
                  }
                })(t, r) ||
                (function () {
                  throw new TypeError(
                    "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                  );
                })()),
            a = o[0],
            i = o[1],
            c = e.children,
            l = e.open,
            s = e.handleClose,
            u = e.btnRef,
            f = a.top,
            d = a.left,
            p = a.upRender;
          return "undefined" == typeof document
            ? null
            : je().createPortal(
                Te.createElement(
                  Se.ZP,
                  {
                    in: l,
                    mountOnEnter: !0,
                    onEnter: function (t) {
                      if (t) {
                        var r = e.btnRef.current.getBoundingClientRect(),
                          n = r.bottom,
                          o = r.left,
                          c = r.right,
                          l = r.width,
                          s = r.top,
                          u = r.height,
                          f = t ? t.getBoundingClientRect() : { width: 0 },
                          d = f.width,
                          p = f.height,
                          m = f.right,
                          h = n + p > window.innerHeight,
                          b = h ? s - p - 4 : s + u + 4,
                          y = { left: c < m ? o + l - d : o };
                        i(
                          Fe(
                            Fe(Fe({}, a), {}, { top: b }, y),
                            {},
                            { upRender: h }
                          )
                        );
                      }
                    },
                    unmountOnExit: !0,
                    timeout: 200,
                  },
                  function (e) {
                    return Te.createElement(
                      Ie,
                      {
                        top: f,
                        left: d,
                        upRender: p,
                        state: e,
                        dropContainerRef: n,
                        handleClose: s,
                        btnRef: u,
                      },
                      c
                    );
                  }
                ),
                document.body
              );
        };
      $e.defaultProps = { children: null, btnRef: null };
      const Xe = $e;
      var We = r(1053),
        Ye = r(1053),
        Ge = r(1341);
      function Je(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function Ke(e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? Je(Object(r), !0).forEach(function (t) {
                Ze(e, t, r[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
            : Je(Object(r)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(r, t)
                );
              });
        }
        return e;
      }
      function Ze(e, t, r) {
        return (
          t in e
            ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = r),
          e
        );
      }
      function Qe(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n;
      }
      var et = Ye,
        tt = et.useState,
        rt = et.useRef,
        nt = et.Fragment;
      const ot = function (e) {
        var t,
          r,
          n = e.children,
          o = e.value,
          a = e.customColors,
          i = void 0 === a ? {} : a,
          c = e.typography,
          l = void 0 === c ? {} : c,
          s = e.placeholderValue,
          u = void 0 === s ? "Choose date" : s,
          f = e.theme,
          d = e.fieldStyle,
          p = e.buttonSize,
          m = e.colors,
          h = e.required,
          b = void 0 !== h && h,
          y = e.dateOptions,
          v = void 0 === y ? {} : y,
          w =
            ((t = tt(!1)),
            (r = 2),
            (function (e) {
              if (Array.isArray(e)) return e;
            })(t) ||
              (function (e, t) {
                var r =
                  null == e
                    ? null
                    : ("undefined" != typeof Symbol && e[Symbol.iterator]) ||
                      e["@@iterator"];
                if (null != r) {
                  var n,
                    o,
                    a = [],
                    i = !0,
                    c = !1;
                  try {
                    for (
                      r = r.call(e);
                      !(i = (n = r.next()).done) &&
                      (a.push(n.value), !t || a.length !== t);
                      i = !0
                    );
                  } catch (e) {
                    (c = !0), (o = e);
                  } finally {
                    try {
                      i || null == r.return || r.return();
                    } finally {
                      if (c) throw o;
                    }
                  }
                  return a;
                }
              })(t, r) ||
              (function (e, t) {
                if (e) {
                  if ("string" == typeof e) return Qe(e, t);
                  var r = Object.prototype.toString.call(e).slice(8, -1);
                  return (
                    "Object" === r && e.constructor && (r = e.constructor.name),
                    "Map" === r || "Set" === r
                      ? Array.from(e)
                      : "Arguments" === r ||
                        /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
                      ? Qe(e, t)
                      : void 0
                  );
                }
              })(t, r) ||
              (function () {
                throw new TypeError(
                  "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                );
              })()),
          O = w[0],
          E = w[1],
          _ = rt(),
          j = v.format,
          S = v.timeSelector,
          C = function (e) {
            return e ? g()(e).setAlpha(0.54).toRgbString() : null;
          },
          P = function () {
            var e =
              "light" === f
                ? l.text.color[0]
                : l.text.color[1] || l.text.color[0];
            return C(i.text) || C(e);
          },
          k = "" === u ? "Choose date" : u,
          N = Ke(
            Ke({}, d.style),
            {},
            {
              backgroundColor: i.fill
                ? i.fill
                : "light" === f
                ? g()(m["dark-shade-color"]).setAlpha(0.12).toRgbString()
                : g()(m["light-shade-color"]).setAlpha(0.24).toRgbString(),
              borderColor:
                i.border ||
                m["".concat("light" === f ? "dark" : "light", "-accent-color")],
              color: i.text,
            }
          );
        return Ye.createElement(
          nt,
          null,
          Ye.createElement(
            "button",
            {
              type: "button",
              onClick: function () {
                E(!O);
              },
              className: "w-date-picker__btn ui-input--size-".concat(p),
              ref: _,
              style: o ? N : Ke(Ke({}, N), {}, { color: P() }),
            },
            Ye.createElement(
              "span",
              {
                className: Ge(
                  "w-date-picker__btn-inner",
                  !o && "w-date-picker__btn-inner--placeholder"
                ),
              },
              o
                ? S
                  ? (0, we.default)(o, "".concat(j, ", HH:mm"))
                  : (0, we.default)(o, j)
                : k,
              Ye.createElement(
                "span",
                { className: "w-date-picker__btn-icon", style: { color: P() } },
                We.createElement(
                  "svg",
                  {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "24",
                    height: "24",
                  },
                  We.createElement(
                    "g",
                    null,
                    We.createElement("path", {
                      d: "M18 6h-1V5c0-.6-.4-1-1-1s-1 .4-1 1v1H9V5c0-.6-.4-1-1-1s-1 .4-1 1v1H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm1 12c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-8h14v8z",
                    }),
                    We.createElement("path", {
                      d: "M7.5 14h1c.3 0 .5-.2.5-.5v-1c0-.3-.2-.5-.5-.5h-1c-.3 0-.5.2-.5.5v1c0 .3.2.5.5.5zm4 0h1c.3 0 .5-.2.5-.5v-1c0-.3-.2-.5-.5-.5h-1c-.3 0-.5.2-.5.5v1c0 .3.2.5.5.5zm4 0h1c.3 0 .5-.2.5-.5v-1c0-.3-.2-.5-.5-.5h-1c-.3 0-.5.2-.5.5v1c0 .3.2.5.5.5zm-8 3h1c.3 0 .5-.2.5-.5v-1c0-.3-.2-.5-.5-.5h-1c-.3 0-.5.2-.5.5v1c0 .3.2.5.5.5zm4 0h1c.3 0 .5-.2.5-.5v-1c0-.3-.2-.5-.5-.5h-1c-.3 0-.5.2-.5.5v1c0 .3.2.5.5.5zm4 0h1c.3 0 .5-.2.5-.5v-1c0-.3-.2-.5-.5-.5h-1c-.3 0-.5.2-.5.5v1c0 .3.2.5.5.5z",
                    })
                  )
                )
              )
            )
          ),
          Ye.createElement("input", {
            type: "date",
            value: o ? (0, we.default)(o, "yyyy-MM-dd") : "",
            id: "form-date",
            "aria-hidden": "true",
            required: b,
            style: {
              position: "absolute",
              height: "100%",
              width: "100%",
              opacity: 0,
              left: 0,
              pointerEvents: "none",
            },
          }),
          Ye.createElement(
            Xe,
            {
              btnRef: _,
              renderInPortal: !0,
              open: O,
              handleClose: function () {
                E(!1);
              },
            },
            n
          )
        );
      };
      var at = r(1053);
      const it = function (e) {
        var t = e.date,
          r = (e.changeYear, e.changeMonth, e.decreaseMonth),
          n = e.increaseMonth;
        return (
          e.prevMonthButtonDisabled,
          e.nextMonthButtonDisabled,
          at.createElement(
            "header",
            { className: "w-date-picker__header" },
            at.createElement(
              "h3",
              { className: "w-date-picker__header-title" },
              at.createElement("button", {
                type: "button",
                onClick: r,
                className:
                  "ui-caption w-date-picker__header-btn w-date-picker__header-btn--left",
              }),
              (0, we.default)(t, "MMMM yyyy"),
              at.createElement("button", {
                type: "button",
                onClick: n,
                className:
                  "w-date-picker__header-btn w-date-picker__header-btn--right",
              })
            )
          )
        );
      };
      var ct = r(1053),
        lt = r(1341);
      function st(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n;
      }
      var ut = ct.useState;
      const ft = function (e) {
        var t,
          r,
          n = e.onChange,
          o = e.buttonSize,
          a = e.customColors,
          i = void 0 === a ? {} : a,
          c = e.theme,
          l = e.typography,
          s = e.placeholder,
          u = e.required,
          f = void 0 !== u && u,
          d = e.dateOptions,
          p = e.fieldStyle,
          m = e.color,
          h = e.colors,
          b = e.value,
          y = void 0 === b ? null : b,
          v = d.format,
          g = d.pastDate,
          w = d.timeSelector,
          O = d.timeStep,
          E =
            ((t = ut(y)),
            (r = 2),
            (function (e) {
              if (Array.isArray(e)) return e;
            })(t) ||
              (function (e, t) {
                var r =
                  null == e
                    ? null
                    : ("undefined" != typeof Symbol && e[Symbol.iterator]) ||
                      e["@@iterator"];
                if (null != r) {
                  var n,
                    o,
                    a = [],
                    i = !0,
                    c = !1;
                  try {
                    for (
                      r = r.call(e);
                      !(i = (n = r.next()).done) &&
                      (a.push(n.value), !t || a.length !== t);
                      i = !0
                    );
                  } catch (e) {
                    (c = !0), (o = e);
                  } finally {
                    try {
                      i || null == r.return || r.return();
                    } finally {
                      if (c) throw o;
                    }
                  }
                  return a;
                }
              })(t, r) ||
              (function (e, t) {
                if (e) {
                  if ("string" == typeof e) return st(e, t);
                  var r = Object.prototype.toString.call(e).slice(8, -1);
                  return (
                    "Object" === r && e.constructor && (r = e.constructor.name),
                    "Map" === r || "Set" === r
                      ? Array.from(e)
                      : "Arguments" === r ||
                        /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
                      ? st(e, t)
                      : void 0
                  );
                }
              })(t, r) ||
              (function () {
                throw new TypeError(
                  "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                );
              })()),
          _ = E[0],
          j = E[1],
          S = function (e) {
            var t = e.getTimezoneOffset();
            j(e),
              n({
                parsedDate: w
                  ? (0, we.default)(e, "".concat(v, ", HH:mm"))
                  : (0, we.default)(e, v),
                date: e.valueOf(),
                offset: t,
              });
          };
        return ct.createElement(
          ot,
          {
            value: y ? _ : null,
            placeholderValue: s,
            buttonSize: o,
            customColors: i,
            theme: c,
            typography: l,
            fieldStyle: p,
            color: m,
            required: f,
            colors: h,
            dateOptions: d,
          },
          ct.createElement(ge(), {
            inline: !0,
            selected: y ? _ : null,
            onChange: S,
            renderCustomHeader: it,
            dayClassName: function () {
              return lt("w-date-picker__day");
            },
            fixedHeight: !0,
            calendarContainer: Ee,
            dateFormat: v,
            minDate: g ? null : Date.now(),
          }),
          w &&
            ct.createElement(ge(), {
              inline: !0,
              showTimeSelect: !0,
              showTimeSelectOnly: !0,
              selected: y ? _ : null,
              onChange: S,
              calendarContainer: Ee,
              fixedHeight: !0,
              className: "w-time-picker",
              dateFormat: "".concat(v, ", HH:mm"),
              timeFormat: "HH:mm",
              timeIntervals: O,
            })
        );
      };
      var dt = r(1053),
        pt = r(1341);
      function mt(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function ht(e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? mt(Object(r), !0).forEach(function (t) {
                bt(e, t, r[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
            : mt(Object(r)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(r, t)
                );
              });
        }
        return e;
      }
      function bt(e, t, r) {
        return (
          t in e
            ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = r),
          e
        );
      }
      var yt = r(1053),
        vt = r(1341),
        gt = [
          "field",
          "formData",
          "onFormReset",
          "validateType",
          "sendingMessage",
          "inSiteRender",
          "onChange",
        ];
      function wt(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function Ot(e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? wt(Object(r), !0).forEach(function (t) {
                Et(e, t, r[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
            : wt(Object(r)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(r, t)
                );
              });
        }
        return e;
      }
      function Et(e, t, r) {
        return (
          t in e
            ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = r),
          e
        );
      }
      var _t = {
          text: ee,
          name: ee,
          email: ee,
          phone: ee,
          file: ee,
          textArea: ye,
          checkbox: ue,
          radioButton: ue,
          accept: y,
          dropDown: N,
          date: function (e) {
            var t = e.title,
              r = e.description,
              n = void 0 === r ? { value: "", active: !1 } : r,
              o = e.value,
              a = e.required,
              i = void 0 !== a && a,
              c = e.onChange,
              l = e.placeholder,
              s = e.fieldClassName,
              u = void 0 === s ? "" : s,
              f = e.buttonSize,
              d = e.borderColor,
              p = e.fillColor,
              m = e.color,
              h = e.theme,
              b = e.colors,
              y = e.fieldStyle,
              v = e.typography,
              g = e.options,
              w = e.labelClassName,
              O = void 0 === w ? "" : w,
              E = e.descriptionClassName,
              _ = void 0 === E ? "" : E,
              j = e.customColors,
              S = void 0 === j ? {} : j,
              C = e.hidden;
            return dt.createElement(
              "div",
              {
                className: pt("w-form__field", u),
                style: ht({}, C && { display: "none" }),
              },
              t &&
                dt.createElement(
                  "p",
                  {
                    className: pt("w-form__label", O),
                    style: { color: S.text },
                  },
                  t,
                  i &&
                    t &&
                    dt.createElement(
                      "span",
                      { title: "Required field", className: "required-mark" },
                      "*"
                    )
                ),
              n.active &&
                dt.createElement(
                  "small",
                  {
                    className: pt("w-form__description", _),
                    style: { color: S.description },
                  },
                  n.value
                ),
              dt.createElement(
                "div",
                { className: "ui-input w-form__input w-relative-wrapper" },
                dt.createElement(ft, {
                  buttonSize: f,
                  borderColor: d,
                  fillColor: p,
                  color: m,
                  theme: h,
                  colors: b,
                  fieldClassName: u,
                  labelClassName: O,
                  descriptionClassName: _,
                  customColors: S,
                  fieldStyle: y,
                  typography: v,
                  required: i,
                  value: o,
                  placeholder: l,
                  dateOptions: g,
                  onChange: c,
                })
              )
            );
          },
        },
        jt = function (e) {
          var t = e.field,
            r = e.formData,
            n = e.onFormReset,
            o = e.validateType,
            a = e.sendingMessage,
            i = e.inSiteRender,
            c = void 0 !== i && i,
            l = e.onChange,
            s = void 0 === l ? function () {} : l,
            u = (function (e, t) {
              if (null == e) return {};
              var r,
                n,
                o = (function (e, t) {
                  if (null == e) return {};
                  var r,
                    n,
                    o = {},
                    a = Object.keys(e);
                  for (n = 0; n < a.length; n++)
                    (r = a[n]), t.indexOf(r) >= 0 || (o[r] = e[r]);
                  return o;
                })(e, t);
              if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                for (n = 0; n < a.length; n++)
                  (r = a[n]),
                    t.indexOf(r) >= 0 ||
                      (Object.prototype.propertyIsEnumerable.call(e, r) &&
                        (o[r] = e[r]));
              }
              return o;
            })(e, gt),
            f = u.fieldClassName,
            d = u.labelClassName,
            p = u.descriptionClassName,
            m = u.value,
            h = m.submitButton,
            b = m.submitButton.size,
            y = void 0 === b ? "md" : b,
            v = m.fieldStyle,
            g = void 0 === v ? {} : v,
            w = m.customColors,
            O = void 0 === w ? {} : w,
            E = u.colors,
            _ = u.typography,
            j = u.background.theme,
            S = u.$block,
            C = u.clipIcon,
            P = _t[t.type],
            k = (r[t.id] || {}).value,
            N = void 0 === k ? "" : k,
            x = Ot(
              Ot(
                Ot(
                  {
                    key: t.id,
                    fieldClassName: f,
                    labelClassName: d,
                    descriptionClassName: p,
                    buttonSize: y,
                    clipIcon: C,
                    fieldStyle: g,
                    customColors: O,
                    colors: E,
                    value: N,
                    typography: _,
                    theme: j,
                    sendingMessage: a,
                  },
                  t
                ),
                "required" in t && { required: t.required && !t.hidden }
              ),
              {},
              {
                type: o,
                onChange: s,
                "data-test": "field",
                id: "".concat(S.anchorId, "-").concat(t.id),
                $block: S,
                onFormReset: n,
                inSiteRender: c,
                submitButton: h,
              }
            );
          return P
            ? "accept" === t.type
              ? yt.createElement(
                  "div",
                  { className: vt("w-form__field", f) },
                  yt.createElement(P, x)
                )
              : yt.createElement(P, x)
            : null;
        };
      jt.defaultProps = {
        className: "",
        fieldClassName: "",
        labelClassName: "",
        descriptionClassName: "",
        clipIcon: !0,
        $block: {},
        validateType: "text",
      };
      const St = jt;
      var Ct = r(1053),
        Pt = r(6568),
        kt = function (e) {
          var t = e.buttonType,
            r = e.theme;
          return Ct.createElement(
            "div",
            {
              className: "w-form__spinner w-form__spinner--"
                .concat(t, "-")
                .concat(r),
            },
            Ct.createElement(
              "div",
              { className: "w-form__spinner-wrapper" },
              Ct.createElement(
                "svg",
                { className: "w-form__spinner-svg", viewBox: "0 0 50 50" },
                Ct.createElement("circle", {
                  className: "w-form__spinner-path",
                  cx: "25",
                  cy: "25",
                  r: "20",
                  fill: "none",
                  strokeWidth: "5",
                })
              )
            )
          );
        };
      (kt.propTypes = { buttonType: Pt.string, theme: Pt.string }),
        (kt.defaultProps = { buttonType: "primary", theme: "light" });
      const Nt = kt;
      var xt = r(1053),
        Rt = r(1341),
        Dt = ["enabled", "advancedEnabled", "eventValue", "nonInteraction"];
      function At() {
        return (
          (At =
            Object.assign ||
            function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var r = arguments[t];
                for (var n in r)
                  Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
              }
              return e;
            }),
          At.apply(this, arguments)
        );
      }
      function Mt(e) {
        return (
          (Mt =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (e) {
                  return typeof e;
                }
              : function (e) {
                  return e &&
                    "function" == typeof Symbol &&
                    e.constructor === Symbol &&
                    e !== Symbol.prototype
                    ? "symbol"
                    : typeof e;
                }),
          Mt(e)
        );
      }
      function qt(e) {
        var t = (function (e, t) {
          if ("object" !== Mt(e) || null === e) return e;
          var r = e[Symbol.toPrimitive];
          if (void 0 !== r) {
            var n = r.call(e, "string");
            if ("object" !== Mt(n)) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return String(e);
        })(e);
        return "symbol" === Mt(t) ? t : String(t);
      }
      function It(e, t) {
        for (var r = 0; r < t.length; r++) {
          var n = t[r];
          (n.enumerable = n.enumerable || !1),
            (n.configurable = !0),
            "value" in n && (n.writable = !0),
            Object.defineProperty(e, n.key, n);
        }
      }
      function Tt(e, t) {
        return (
          (Tt =
            Object.setPrototypeOf ||
            function (e, t) {
              return (e.__proto__ = t), e;
            }),
          Tt(e, t)
        );
      }
      function Bt(e) {
        if (void 0 === e)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return e;
      }
      function Ft(e) {
        return (
          (Ft = Object.setPrototypeOf
            ? Object.getPrototypeOf
            : function (e) {
                return e.__proto__ || Object.getPrototypeOf(e);
              }),
          Ft(e)
        );
      }
      function Lt(e, t, r, n, o, a, i) {
        try {
          var c = e[a](i),
            l = c.value;
        } catch (e) {
          return void r(e);
        }
        c.done ? t(l) : Promise.resolve(l).then(n, o);
      }
      function zt(e) {
        return function () {
          var t = this,
            r = arguments;
          return new Promise(function (n, o) {
            var a = e.apply(t, r);
            function i(e) {
              Lt(a, n, o, i, c, "next", e);
            }
            function c(e) {
              Lt(a, n, o, i, c, "throw", e);
            }
            i(void 0);
          });
        };
      }
      function Ht(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t &&
            (n = n.filter(function (t) {
              return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })),
            r.push.apply(r, n);
        }
        return r;
      }
      function Vt(e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = null != arguments[t] ? arguments[t] : {};
          t % 2
            ? Ht(Object(r), !0).forEach(function (t) {
                Ut(e, t, r[t]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
            : Ht(Object(r)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(r, t)
                );
              });
        }
        return e;
      }
      function Ut(e, t, r) {
        return (
          t in e
            ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = r),
          e
        );
      }
      function $t(e, t) {
        if (null == e) return {};
        var r,
          n,
          o = (function (e, t) {
            if (null == e) return {};
            var r,
              n,
              o = {},
              a = Object.keys(e);
            for (n = 0; n < a.length; n++)
              (r = a[n]), t.indexOf(r) >= 0 || (o[r] = e[r]);
            return o;
          })(e, t);
        if (Object.getOwnPropertySymbols) {
          var a = Object.getOwnPropertySymbols(e);
          for (n = 0; n < a.length; n++)
            (r = a[n]),
              t.indexOf(r) >= 0 ||
                (Object.prototype.propertyIsEnumerable.call(e, r) &&
                  (o[r] = e[r]));
        }
        return o;
      }
      var Xt = /^\+?(\d+)?$/g,
        Wt = function () {
          var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : {},
            t = e.enabled,
            r = e.advancedEnabled,
            n = e.eventValue,
            o = e.nonInteraction,
            a = $t(e, Dt);
          if (t) {
            var i = r ? { eventValue: n, nonInteraction: o } : {};
            !(function (e) {
              var t = e.eventCategory,
                r = void 0 === t ? "Editor" : t,
                n = e.eventAction,
                o = e.eventLabel,
                a = e.eventValue,
                i = e.nonInteraction,
                c = void 0 === i || i;
              window.ga &&
                window.ga("send", {
                  hitType: "event",
                  eventCategory: r,
                  eventAction: n,
                  eventLabel: o,
                  eventValue: a,
                  nonInteraction: c,
                }),
                window.gtag &&
                  window.gtag("event", n, {
                    event_category: r,
                    event_action: n,
                    event_label: o,
                    value: a,
                  });
            })(Vt(Vt({ nonInteraction: !1 }, a), i));
          }
        },
        Yt = (function () {
          var e = zt(
            regeneratorRuntime.mark(function e(t) {
              var r, n, o;
              return regeneratorRuntime.wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        (e.next = 2),
                        window.fetch(
                          "".concat(
                            "https://us-central1-weblium-contact-form-app.cloudfunctions.net",
                            "/submit/check-recaptcha"
                          ),
                          { method: "POST", body: t }
                        )
                      );
                    case 2:
                      return (r = e.sent), (e.next = 5), r.json();
                    case 5:
                      return (
                        (n = e.sent),
                        (o = r.status >= 300),
                        e.abrupt(
                          "return",
                          Vt(Vt({}, n), {}, { status: r.status, error: o })
                        )
                      );
                    case 8:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          );
          return function (t) {
            return e.apply(this, arguments);
          };
        })(),
        Gt = (function () {
          var e = zt(
            regeneratorRuntime.mark(function e(t, r) {
              var n, o, a;
              return regeneratorRuntime.wrap(function (e) {
                for (;;)
                  switch ((e.prev = e.next)) {
                    case 0:
                      return (
                        (e.next = 2),
                        window.fetch(
                          "".concat(
                            "https://us-central1-weblium-contact-form-app.cloudfunctions.net",
                            "/submit"
                          ),
                          {
                            method: "POST",
                            body: t,
                            headers: r && new Headers(r),
                          }
                        )
                      );
                    case 2:
                      return (n = e.sent), (e.next = 5), n.json();
                    case 5:
                      return (
                        (o = e.sent),
                        (a = n.status >= 300),
                        e.abrupt(
                          "return",
                          Vt(Vt({}, o), {}, { status: n.status, error: a })
                        )
                      );
                    case 8:
                    case "end":
                      return e.stop();
                  }
              }, e);
            })
          );
          return function (t, r) {
            return e.apply(this, arguments);
          };
        })(),
        Jt = (function (e) {
          !(function (e, t) {
            if ("function" != typeof t && null !== t)
              throw new TypeError(
                "Super expression must either be null or a function"
              );
            (e.prototype = Object.create(t && t.prototype, {
              constructor: { value: e, writable: !0, configurable: !0 },
            })),
              t && Tt(e, t);
          })(s, e);
          var t,
            r,
            n,
            o,
            a,
            i =
              ((o = s),
              (a = (function () {
                if ("undefined" == typeof Reflect || !Reflect.construct)
                  return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                  return (
                    Boolean.prototype.valueOf.call(
                      Reflect.construct(Boolean, [], function () {})
                    ),
                    !0
                  );
                } catch (e) {
                  return !1;
                }
              })()),
              function () {
                var e,
                  t = Ft(o);
                if (a) {
                  var r = Ft(this).constructor;
                  e = Reflect.construct(t, arguments, r);
                } else e = t.apply(this, arguments);
                return (function (e, t) {
                  if (t && ("object" === Mt(t) || "function" == typeof t))
                    return t;
                  if (void 0 !== t)
                    throw new TypeError(
                      "Derived constructors may only return object or undefined"
                    );
                  return Bt(e);
                })(this, e);
              });
          function s() {
            var e;
            !(function (e, t) {
              if (!(e instanceof t))
                throw new TypeError("Cannot call a class as a function");
            })(this, s);
            for (var t = arguments.length, r = new Array(t), n = 0; n < t; n++)
              r[n] = arguments[n];
            return (
              Ut(Bt((e = i.call.apply(i, [this].concat(r)))), "state", {
                formData: {},
                filledByBotValue: "",
                recaptchaEnabled: null,
                recaptchaSiteKey: null,
              }),
              Ut(Bt(e), "formRef", xt.createRef()),
              Ut(Bt(e), "setInputState", function (t) {
                var r = t.id,
                  n = t.title,
                  o = t.type,
                  a = t.placeholder,
                  i =
                    arguments.length > 1 && void 0 !== arguments[1]
                      ? arguments[1]
                      : {},
                  l = e.state.formData,
                  s = i.target,
                  u = void 0 === s ? {} : s,
                  f = null == u.value ? i : u.value;
                if ("checkbox" === o && "checkbox" === u.type)
                  (f = l[r] ? Vt({}, l[r].value) : {}),
                    u.checked ? (f[u.id] = u.value) : delete f[u.id];
                else if ("date" === o) f = i;
                else if ("accept" === o) f = u.checked ? "Yes" : "No";
                else if ("phone" === o && !f.match(Xt)) return;
                if (f)
                  e.setState(function (e) {
                    return Vt(
                      Vt({}, e),
                      {},
                      {
                        formData: Vt(
                          Vt({}, e.formData),
                          {},
                          Ut({}, r, { title: c(n) || c(a), value: f, type: o })
                        ),
                      }
                    );
                  });
                else {
                  var d = e.state.formData,
                    p = (d[r], $t(d, [r].map(qt)));
                  e.setState({ formData: p });
                }
              }),
              Ut(Bt(e), "callAction", function () {
                var t = e.props.callAction;
                if (!t) return e.showSuccessMessage();
                if ("close-popup" === t.type) {
                  var r = e.formRef.current.closest(".popup");
                  if (!r) return;
                  var n = r.getAttribute("data-popup-anchor");
                  return window.closePopup(n);
                }
                var o = t.href,
                  a = t.linkTarget;
                a ? window.open(o, a) : (window.location.href = o);
              }),
              Ut(Bt(e), "handleHooks", function () {
                var t = e.props.bind,
                  r = window.formHooks,
                  n = (void 0 === r ? {} : r)[t] || [];
                return Promise.all(
                  n.map(function (t) {
                    return t(e.state.formData);
                  })
                );
              }),
              Ut(Bt(e), "checkRequired", function () {
                return e.props.fields
                  .filter(function (e) {
                    var t = e.required,
                      r = e.hidden;
                    return t && !r;
                  })
                  .map(function (e) {
                    return e.id;
                  })
                  .every(function (t) {
                    var r = e.state.formData[t] && e.state.formData[t].value;
                    if (r)
                      return "object" === Mt(r)
                        ? Object.keys(r).length
                        : r.length;
                  });
              }),
              Ut(Bt(e), "getFormData", function () {
                var t = e.props,
                  r = t._token,
                  n = t.fields;
                return (function () {
                  var e =
                      arguments.length > 0 && void 0 !== arguments[0]
                        ? arguments[0]
                        : {},
                    t = arguments.length > 2 ? arguments[2] : void 0,
                    r = (arguments.length > 1 ? arguments[1] : void 0).filter(
                      function (t) {
                        var r = t.type,
                          n = t.id;
                        return "hidden" === r || e[n];
                      }
                    ),
                    n = new FormData();
                  return (
                    t && n.append("token", t),
                    r.forEach(function (t) {
                      var r = t.id,
                        o = t.type,
                        a = t.activeParameters;
                      "hidden" === o
                        ? a
                            .map(function (e) {
                              return {
                                key: e,
                                value: window.localStorage.getItem(e),
                              };
                            })
                            .filter(function (e) {
                              return e.value;
                            })
                            .forEach(function (e) {
                              var t = e.key,
                                r = e.value;
                              n.append(
                                t,
                                JSON.stringify({
                                  title: t,
                                  value: r,
                                  type: "hidden",
                                })
                              );
                            })
                        : n.append(r, JSON.stringify(e[r]));
                    }),
                    n.append("referer", window.location.href),
                    n
                  );
                })(e.state.formData, n, r);
              }),
              Ut(
                Bt(e),
                "makeSubmit",
                (function () {
                  var t = zt(
                    regeneratorRuntime.mark(function t(r) {
                      var n, o, a;
                      return regeneratorRuntime.wrap(function (t) {
                        for (;;)
                          switch ((t.prev = t.next)) {
                            case 0:
                              return (
                                (n = e.getFormData()),
                                (o = r && { recaptcha: r }),
                                (t.next = 4),
                                e.handleHooks()
                              );
                            case 4:
                              return (t.next = 6), Gt(n, o);
                            case 6:
                              null != (a = t.sent) && a.error
                                ? e.showErrorMessage()
                                : e.callAction(),
                                e.resetForm({ sendingMessage: !1 });
                            case 9:
                            case "end":
                              return t.stop();
                          }
                      }, t);
                    })
                  );
                  return function (e) {
                    return t.apply(this, arguments);
                  };
                })()
              ),
              Ut(
                Bt(e),
                "handleSubmitForm",
                (function () {
                  var t = zt(
                    regeneratorRuntime.mark(function t(r) {
                      var n, o;
                      return regeneratorRuntime.wrap(
                        function (t) {
                          for (;;)
                            switch ((t.prev = t.next)) {
                              case 0:
                                if (
                                  (r.preventDefault(),
                                  r.stopPropagation(),
                                  e.setState({ sendingMessage: !0 }),
                                  e.checkRequired() || e.state.recaptchaEnabled)
                                ) {
                                  t.next = 5;
                                  break;
                                }
                                return t.abrupt(
                                  "return",
                                  e.setState({ sendingMessage: !1 })
                                );
                              case 5:
                                if (!e.state.filledByBotValue) {
                                  t.next = 9;
                                  break;
                                }
                                return (
                                  e.callAction(),
                                  e.resetForm({
                                    sendingMessage: !e.state.recaptchaEnabled,
                                  }),
                                  t.abrupt("return")
                                );
                              case 9:
                                if (
                                  ((t.prev = 9),
                                  Wt(e.props.ga),
                                  !e.state.recaptchaEnabled)
                                ) {
                                  t.next = 16;
                                  break;
                                }
                                return (
                                  (t.next = 14),
                                  p(e.makeSubmit, e.state.recaptchaSiteKey)
                                );
                              case 14:
                                t.next = 18;
                                break;
                              case 16:
                                return (t.next = 18), e.makeSubmit();
                              case 18:
                                t.next = 27;
                                break;
                              case 20:
                                (t.prev = 20),
                                  (t.t0 = t.catch(9)),
                                  (n = t.t0.message),
                                  (o =
                                    "Can't send Contact Form. Error: ".concat(
                                      JSON.stringify(n)
                                    )),
                                  console.error(o),
                                  e.showErrorMessage(),
                                  e.resetForm({ sendingMessage: !1 });
                              case 27:
                              case "end":
                                return t.stop();
                            }
                        },
                        t,
                        null,
                        [[9, 20]]
                      );
                    })
                  );
                  return function (e) {
                    return t.apply(this, arguments);
                  };
                })()
              ),
              Ut(Bt(e), "observers", []),
              Ut(Bt(e), "submitSubject", {
                subscribe: function (t) {
                  e.observers.push(t);
                  var r = e.observers.length - 1;
                  return {
                    unsubscribe: function () {
                      e.observers.splice(r, 1);
                    },
                  };
                },
                complete: function () {
                  e.observers.forEach(function (e) {
                    return e();
                  });
                },
              }),
              Ut(Bt(e), "onFormReset", function (t) {
                return e.submitSubject.subscribe(t);
              }),
              Ut(Bt(e), "resetForm", function (t) {
                var r = t.sendingMessage;
                e.setState({ formData: {}, sendingMessage: !!r }),
                  e.submitSubject.complete();
              }),
              Ut(Bt(e), "messageClick", function (t) {
                return function (r) {
                  for (var n = r.target; n !== t; ) {
                    var o = n.dataset;
                    o &&
                      "close" === o.role &&
                      (e.closeSuccessMessage(), e.closeErrorMessage()),
                      (n = n.parentNode);
                  }
                };
              }),
              Ut(Bt(e), "showSuccessMessage", function () {
                var t = document.createElement("div");
                (t.className = "w-block-wrapper"),
                  (t.innerHTML = e.props.successMessage),
                  (t.onclick = e.messageClick(t)),
                  (e.successMessage = document.body.appendChild(t)),
                  e.successMessage
                    .querySelector(
                      '[data-message-content="w-form-modal__content"]'
                    )
                    .classList.add("w-form-modal__content--entering");
              }),
              Ut(Bt(e), "showErrorMessage", function () {
                var t = document.createElement("div");
                (t.className = "w-block-wrapper"),
                  (t.innerHTML = e.props.errorMessage),
                  (t.onclick = e.messageClick(t)),
                  (e.errorMessage = document.body.appendChild(t)),
                  e.successMessage
                    .querySelector(
                      '[data-message-content="w-form-modal__content"]'
                    )
                    .classList.add("w-form-modal__content--entering");
              }),
              Ut(Bt(e), "closeSuccessMessage", function () {
                if (e.successMessage) {
                  var t = e.successMessage.querySelector(
                      '[data-message-content="w-form-modal__content"]'
                    ),
                    r = e.successMessage.querySelector(
                      '[data-message-content="w-form-modal__overlay"]'
                    );
                  t.classList.add("w-form-modal__content--exiting"),
                    r.classList.add("w-form-modal__overlay--exiting"),
                    r || document.body.removeChild(e.successMessage),
                    r.addEventListener("transitionend", function () {
                      document.body.removeChild(e.successMessage);
                    });
                }
              }),
              Ut(Bt(e), "closeErrorMessage", function () {
                e.errorMessage && document.body.removeChild(e.errorMessage);
              }),
              Ut(Bt(e), "renderIcon", function () {
                var t = e.props,
                  r = t.iconHtml,
                  n = t.iconAttributes;
                return xt.createElement(
                  "span",
                  At({ dangerouslySetInnerHTML: { __html: r } }, n)
                );
              }),
              Ut(Bt(e), "handleChangeBotValue", function (t) {
                e.setState({ filledByBotValue: t.target.value });
              }),
              e
            );
          }
          return (
            (t = s),
            (r = [
              {
                key: "checkAndInitRecaptcha",
                value:
                  ((n = zt(
                    regeneratorRuntime.mark(function e() {
                      var t, r, n, o, a, i, c;
                      return regeneratorRuntime.wrap(
                        function (e) {
                          for (;;)
                            switch ((e.prev = e.next)) {
                              case 0:
                                return (
                                  (t = this.props._token),
                                  (r = this.getFormData()),
                                  (e.next = 4),
                                  Yt(r)
                                );
                              case 4:
                                return (n = e.sent), (e.next = 7), f(t);
                              case 7:
                                (o = e.sent),
                                  (a = null == o ? void 0 : o.site_key),
                                  (i = n.active),
                                  (c = i && a),
                                  this.setState({
                                    recaptchaSiteKey: a,
                                    recaptchaEnabled: c,
                                  }),
                                  c && d(a);
                              case 13:
                              case "end":
                                return e.stop();
                            }
                        },
                        e,
                        this
                      );
                    })
                  )),
                  function () {
                    return n.apply(this, arguments);
                  }),
              },
              {
                key: "componentDidMount",
                value: function () {
                  this.checkAndInitRecaptcha();
                  var e = this.props.fields.filter(function (e) {
                    return "hidden" === e.type;
                  });
                  if (e.length && window.location.search) {
                    var t = l(window.location.search);
                    e.forEach(function (e) {
                      var r = e.activeParameters;
                      (void 0 === r ? [] : r).forEach(function (e) {
                        t[e] && window.localStorage.setItem(e, t[e]);
                      });
                    });
                  }
                },
              },
              {
                key: "render",
                value: function () {
                  var e = this,
                    t = this.props,
                    r = t.fields,
                    n = t.submitClassName,
                    o = t.submitButton,
                    a = t.iconEnabled,
                    i = void 0 !== a && a,
                    c = t.theme,
                    l = this.state.sendingMessage;
                  return xt.createElement(
                    xt.Fragment,
                    null,
                    xt.createElement(
                      "form",
                      { onSubmit: this.handleSubmitForm, ref: this.formRef },
                      r.map(function (t) {
                        return xt.createElement(
                          St,
                          At(
                            {
                              field: t,
                              value: e.props.value,
                              formData: e.state.formData,
                              onFormReset: e.onFormReset,
                              validateType:
                                ((r = t.type),
                                "phone" === r
                                  ? "tel"
                                  : "name" === r
                                  ? "text"
                                  : r),
                              sendingMessage: l,
                              onChange: function (r) {
                                return e.setInputState(t, r);
                              },
                              inSiteRender: !0,
                              theme: c,
                            },
                            e.props
                          )
                        );
                        var r;
                      }),
                      xt.createElement("input", {
                        type: "text",
                        autoComplete: "off",
                        className: "honey-field",
                        value: this.state.filledByBotValue,
                        onChange: this.handleChangeBotValue,
                      }),
                      this.state.recaptchaEnabled &&
                        xt.createElement("input", {
                          type: "hidden",
                          name: "recaptcha_response",
                          id: "recaptchaResponse",
                          className: "honey-field",
                        }),
                      o &&
                        xt.createElement(
                          "button",
                          {
                            type: "submit",
                            className: Rt(n, "g-recaptcha"),
                            style: l ? { pointerEvents: "none" } : {},
                            "data-sitekey": this.state.recaptchaEnabled,
                            "data-action": "submit",
                          },
                          xt.createElement("span", {
                            className: Rt(
                              "w-form-button__border",
                              "ui-button__border"
                            ),
                          }),
                          xt.createElement(
                            "span",
                            { className: Rt("w-form-button__content") },
                            xt.createElement(
                              "span",
                              { className: Rt("w-form-button__inner") },
                              xt.createElement(
                                "span",
                                {
                                  className: "w-form-button__text",
                                  style: l ? { opacity: 0 } : {},
                                },
                                o.title
                              ),
                              i && this.renderIcon(),
                              l &&
                                xt.createElement(Nt, {
                                  type: o.buttonType,
                                  theme: c,
                                })
                            )
                          )
                        )
                    )
                  );
                },
              },
            ]),
            r && It(t.prototype, r),
            s
          );
        })(xt.Component);
      Jt.defaultProps = { fields: [] };
    },
  },
]);
